export const Greet = ({username})=>{
    const sayGreet = ()=>{
        const date = new Date();
        const hour = date.getHours();
        if(hour<12){
            return (<h1>Good Morning {username}</h1>)
            // return (<h1>Good Morning {props.username}</h1>)
        }
        else if (hour>=12 && hour<=16){
            return (<h1>Good AfterNoon {username}</h1>)
        }
        else{
            return (<h1>Good Evening {username}</h1>)
        }
    }
    return (<>
        {sayGreet()}
        </>)
}