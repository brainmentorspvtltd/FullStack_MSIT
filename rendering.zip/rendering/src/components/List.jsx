export const List =()=>{
    const fruits = ["Apple", "Orange", "Mango"];
    return (
        <>
        {fruits.map((fruit, index)=><p key={index}>{fruit}</p>)}
        </>
    );
}