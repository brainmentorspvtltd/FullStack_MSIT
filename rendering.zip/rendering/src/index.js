/*
Bridge file b/w App.js and index.html
By Using ReactDOM VDOM convert DOM
*/
import ReactDOM from 'react-dom/client';
import App from './App';
const div = document.querySelector('#root'); // DOM
const root = ReactDOM.createRoot(div);
root.render(<App/>); // Calling App Component But in JSX Style