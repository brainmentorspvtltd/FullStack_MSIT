// Now Write the First Component/ Root Component

import React from "react";
import { Greet } from "./components/Greet";
import { List } from "./components/List";

// Arrow Function
const App = ()=>{
  const logic = ()=>{
    if(role ==='Admin'){
      return <h3>Welcome {role}</h3>
    }
    else if(role ==='Manager'){
      return <h4>Hi {role}</h4>
    }
    else {
      return <h5>Hello {role}</h5>
    }
  }
  const name = 'Ram';
  const role = 'Admin';
  // document.createElement('p'); // DOM
  return (
    <>
    <input type='text' placeholder='Type Your Name'/>
    <h1>Welcome {name}</h1>
    {/* <p>{role==='Admin'?'Welcome Admin':'Hello Guest'}</p> */}
    {logic()}
    <h2>Hi React JS {Date.now()}</h2>
    <Greet username= {name}/>
    <List/>
    </>
  )  
  // return React.createElement('div',null
  // ,React.createElement('h1', null, 'Hello React JS....'),
  // React.createElement('h2', null, 'Hi React JS'));
    //,;
    //return (<h1>Hello React JS</h1>)
}
export default App;