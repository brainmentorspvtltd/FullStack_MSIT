export const userController = {
    login(request, response){
        response.json({message:'Login'});
    },
    register(request, response){
        response.json({message:'Register'});
    },
    profile(request, response){
        response.json({message:'Profile'});
    },
    changePassword(request, response){
        response.json({message:'Change Password'});
    }
}