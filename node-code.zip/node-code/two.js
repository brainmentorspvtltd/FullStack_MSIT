const fs = require('fs');
const path ='/Users/amitsrivastava/Documents/fenwick-rec/2023-08-13 17-14-08.mp4';
const stream = fs.createReadStream(path,{highWaterMark:200});
stream.on('open', ()=>{
    console.log('Stream Open...');
});
stream.on('data',(chunk)=>{
    console.log('Chunk is ', chunk);
});
stream.on('end',()=>{
    console.log('Stream Ends');
});