// console.log('Hello Node JS');
// var a= 10;
// var b = 20;
// var c = a + b;
// console.log('C is ',c);
// FS Module
console.log('Code Starts'); // Sync
const fs = require('fs'); // Sync
const filePath = '/Users/amitsrivastava/Documents/online-code-ide/node-code/sample.txt'; // Sync
// Async
fs.readFile(filePath, (err, content)=>{
    if(err){
        console.log('Unable to read a file ', err);
    }
    else{
        console.log('File Content is ', content.toString());
    }
}) ;// Async

fs.readFile(__filename, (err, content)=>{
    if(err){
        console.log('Unable to read a file ', err);
    }
    else{
        console.log('*******File Content is ', content.toString());
    }
})
console.log('Current File Path is ', __filename);
console.log("Current Dir Path ", __dirname);
console.log('Code Ends');