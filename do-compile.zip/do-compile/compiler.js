import childProcess from 'child_process';
//console.log(childProcess);
const fileName = 'Solution';
const buffer = childProcess.execSync(`javac ${fileName}.java`);
console.log(buffer.toString());
const buffer2 = childProcess.execSync(`java ${fileName}`);
console.log(buffer2.toString());