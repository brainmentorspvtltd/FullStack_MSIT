 const URL = 'https://raw.githubusercontent.com/Skill-risers/pizzajson/main/pizza.json';
 export default URL;