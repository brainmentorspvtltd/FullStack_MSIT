import logo from './logo.svg';
import './App.css';
import { QuestionPage } from './modules/ide/pages/QuestionPage';

import { UserPage } from './modules/user/pages/UserPage';

function App() {
  return (
   <UserPage/>
  );
}

export default App;
