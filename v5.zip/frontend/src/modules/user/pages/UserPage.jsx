import React from 'react'
import { Register } from '../components/Register'
import { Typography } from '@mui/material'
import { Login } from '../components/Login'

export const UserPage = () => {
  return (
    <>
    <Typography>Register</Typography>
    {/* <Register/> */}
    <Login/>
    </>
  )
}
