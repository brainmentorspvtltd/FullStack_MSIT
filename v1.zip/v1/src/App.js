import logo from './logo.svg';
import './App.css';
import { QuestionPage } from './modules/ide/pages/QuestionPage';

function App() {
  return (
   <QuestionPage/>
  );
}

export default App;
