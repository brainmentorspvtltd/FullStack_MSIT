// Product Controller - It is a Glue B/w View and Model
// Controller - I/O View Layer
// Data Exchange B/w View and Model.