// HTTP/ HTTPS Call
import URL from '../utils/constant.js';
function makeNetworkCall(){
    fetch()
}
